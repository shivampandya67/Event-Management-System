package Controller;

import java.util.List;

import Model.User;

import Model.UserDao;
import View.DashboardView;
import View.LoginView;

public class LoginController {
    private LoginView view;
    private UserDao userDao;

    public LoginController(LoginView view, UserDao userDao) {
        this.view = view;
        this.userDao = userDao;

        // Attach event listener to submit button
        view.addSubmitActionListener(e -> login());
    }

    private void login() {
        String email = view.getEmail();
        String password = view.getPassword();

        // Authenticate user
        boolean isAuthenticated = userDao.authenticateUser(email, password);

        if (isAuthenticated) {
            // Login successful
            view.showSuccessMessage("Login successful");

            // Fetch the logged-in user's email
            String loggedInUserEmail = email;

            List<User> users = userDao.getAllUsers();
            // Open the dashboard view with the list of users
            openDashboardView(users, loggedInUserEmail);

            // Close the login view
            view.dispose();
        } else {
            // Login failed
            view.showErrorMessage("Invalid email or password");
        }
    }

    private void openDashboardView(List<User> users, String loggedInUserEmail) {
        // Fetch all users


        // Instantiate the DashboardView with the list of users
        DashboardView dashboardView = new DashboardView(users, loggedInUserEmail);
        dashboardView.setVisible(true);
    }

    public static void main(String[] args) {
        // Instantiate and initialize view and model
        LoginView view = new LoginView();
        UserDao userDao = new UserDao();

        // Instantiate controller
        LoginController controller = new LoginController(view, userDao);

        // Display the login view
        view.setVisible(true);
    }
}

