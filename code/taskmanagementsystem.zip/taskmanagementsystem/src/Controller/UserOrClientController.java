package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import Model.User;
import Model.UserDao;
import View.ClientDashboardView;
import View.LoginView;
import View.UserOrClient;

public class UserOrClientController {
    private UserOrClient view;
    private UserDao userDao;

    public UserOrClientController(UserOrClient view, UserDao userDao) {
        this.view = view;
        this.userDao = userDao;

        // Attach event listeners to the view
        view.addClientButtonListener(new ClientButtonListener());
        view.addUserButtonListener(new UserButtonListener());
    }

    // Action listener for the client button
    class ClientButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Log message to console
            System.out.println("Client button clicked");
            
            // Open the client dashboard
            List<User> users = userDao.getAllUsers();
            ClientDashboardView clientDashboardView = new ClientDashboardView(users);
            clientDashboardView.setVisible(true);
            view.dispose(); // Close the current window
        }
    }

    // Action listener for the user button
    class UserButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Log message to console
            System.out.println("User button clicked");

            // Open the login page with corresponding logic and database operations
            openLoginView();
            
            // Close the current window
            view.dispose();
        }

        private void openLoginView() {
            // Instantiate the login view
            LoginView loginView = new LoginView();
            // Instantiate the login controller with the view and userDao
            LoginController loginController = new LoginController(loginView, userDao);
            // Display the login view
            loginView.setVisible(true);
        }
    }

    public static void main(String[] args) {
        UserOrClient userOrClient = new UserOrClient();
        UserDao userDao = new UserDao(); // Instantiate UserDao
        UserOrClientController controller = new UserOrClientController(userOrClient, userDao);
        userOrClient.setVisible(true);
    }
}
