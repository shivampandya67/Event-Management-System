package Model;

import java.sql.Date;
import java.util.List;

public class Meeting {
    private int id; // Unique ID for the meeting
    private Date meetingDate;
    private String startTime;
    private String endTime;
    private String userEmail;
    private List<String> participants;

    public Meeting(Integer id,Date meetingDate, String startTime, String endTime, String userEmail, List<String> participants) {
        this.id = id;
        this.meetingDate = meetingDate;
        this.startTime = startTime;
        this.endTime = endTime;
        this.userEmail = userEmail;
        this.participants = participants;
    }

    public int getId() {
        return id;
    }

    public Date getMeetingDate() {
        return meetingDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public List<String> getParticipants() {
        return participants;
    }
}
