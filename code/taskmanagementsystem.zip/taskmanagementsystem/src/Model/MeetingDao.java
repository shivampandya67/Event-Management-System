package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MeetingDao {
    private Connection connection;
	private Object hostTableModel;

    public MeetingDao() {
        // Initialize database connection
        try {
            connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/taskmanagement", "root", "root");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertMeeting(String user_email, java.sql.Date date, String startTime, String endTime, List<String> userEmails) {
        try {
            // Prepare SQL statement to insert a meeting into the database
            PreparedStatement statement = connection.prepareStatement("INSERT INTO meetings (user_email, meeting_date, start_time, end_time, participants) VALUES (?, ?, ?, ?, ?)");
            
            // Set parameters for the SQL statement
            statement.setString(1, user_email);
            statement.setDate(2, date);
            statement.setString(3, startTime);
            statement.setString(4, endTime);
            
            // Construct participants string
            StringBuilder participantsBuilder = new StringBuilder();
            for (String userEmail : userEmails) {
                participantsBuilder.append(userEmail).append(",");
            }
            String participants = participantsBuilder.toString();
            // Remove the trailing comma
            if (participants.length() > 0) {
                participants = participants.substring(0, participants.length() - 1);
            }

            // Set participants parameter
            statement.setString(5, participants);
            
            // Execute the SQL statement
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Meeting> getMeetingsForCurrentUser(String userEmail) {
    List<Meeting> meetings = new ArrayList<>();
    try {
        // Prepare SQL statement to retrieve meetings for the current user
        String query = "SELECT * FROM meetings WHERE participants LIKE ? OR user_email = ?";

        PreparedStatement statement = connection.prepareStatement(query);
        
        // Set parameters for the SQL statement
        statement.setString(1, "%" + userEmail + "%");
        statement.setString(2, userEmail);

        // Execute the query
        ResultSet resultSet = statement.executeQuery();

        // Process the result set
        while (resultSet.next()) {
            // Extract meeting data from the result set
            String user_email = resultSet.getString("user_email");
            java.sql.Date date = resultSet.getDate("meeting_date");
            String startTime = resultSet.getString("start_time");
            String endTime = resultSet.getString("end_time");
            Integer id=resultSet.getInt("meeting_id");
            String participantsString = resultSet.getString("participants");
          
            
            List<String> participants = Arrays.asList(participantsString.split(","));

            // Create a Meeting object and add it to the list
            Meeting meeting = new Meeting(id, date, startTime, endTime, user_email, participants);
            meetings.add(meeting);

            // Log retrieved meeting
//            System.out.println("Retrieved Meeting: " + meeting);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return meetings;
}

    public boolean isMeetingConflict(Meeting meeting, List<String> userEmails) {
        try {
            // Prepare SQL statement to check for meeting conflicts
            PreparedStatement statement = connection.prepareStatement
            		("SELECT * FROM meetings WHERE (user_email = ? OR participants LIKE ?) AND ((meeting_date = ? AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?))) OR (meeting_date = ? AND ((start_time >= ? AND start_time < ?) OR (end_time > ? AND end_time <= ?))) OR (meeting_date > ? AND meeting_date < ?))");

            
            // Set parameters for the SQL statement
            statement.setString(1, meeting.getUserEmail());
            statement.setString(2, "%" + meeting.getUserEmail() + "%");
            statement.setDate(3, meeting.getMeetingDate());
            statement.setString(4, meeting.getStartTime());
            statement.setString(5, meeting.getStartTime());
            statement.setString(6, meeting.getEndTime());
            statement.setString(7, meeting.getEndTime());
            statement.setDate(8, meeting.getMeetingDate());
            statement.setString(9, meeting.getStartTime());
            statement.setString(10, meeting.getEndTime());
            statement.setString(11, meeting.getStartTime());
            statement.setString(12, meeting.getEndTime());
            statement.setDate(13, meeting.getMeetingDate());
            statement.setDate(14, meeting.getMeetingDate());

            // Execute the query
            ResultSet resultSet = statement.executeQuery();

            // If there are any rows returned, it means there is a conflict
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            // In case of exception, assume there is a conflict to prevent scheduling
            return true;
        }
    }

    
    public boolean insertMeetingFromForm(Meeting newMeeting, List<String> userEmails) {
        try {
            // Check for meeting conflicts
            if (isMeetingConflict(newMeeting, userEmails)) {
                return false; // Return false if there's a conflict
            }
            
            // Prepare SQL statement to insert a meeting into the database
            PreparedStatement statement = connection.prepareStatement("INSERT INTO meetings (user_email, meeting_date, start_time, end_time, participants) VALUES (?, ?, ?, ?, ?)");
            
            // Set parameters for the SQL statement using the Meeting object
            statement.setString(1, newMeeting.getUserEmail());
            statement.setDate(2, newMeeting.getMeetingDate());
            statement.setString(3, newMeeting.getStartTime());
            statement.setString(4, newMeeting.getEndTime());
            
            // Construct participants string
            StringBuilder participantsBuilder = new StringBuilder();
            for (String userEmail : userEmails) {
                participantsBuilder.append(userEmail).append(",");
            }
            String participants = participantsBuilder.toString();
            // Remove the trailing comma
            if (participants.length() > 0) {
                participants = participants.substring(0, participants.length() - 1);
            }

            // Set participants parameter
            statement.setString(5, participants);
            
            // Execute the SQL statement
            statement.executeUpdate();
            
            return true; // Return true if insertion is successful
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if an exception occurs
        }
    }

    public void updateMeeting(String userEmail, int meetingId, Date meetingDate, String startTime, String endTime) {
        try {
            // Prepare SQL statement to update the meeting in the database
            PreparedStatement statement = connection.prepareStatement("UPDATE meetings SET start_time=?, end_time=? WHERE user_email=? AND meeting_id=?");
            statement.setString(1, startTime);
            statement.setString(2, endTime);
            statement.setString(3, userEmail);
            statement.setInt(4, meetingId);

            statement.executeUpdate();
        } catch (SQLException e) {
            // Handle any SQL exceptions
            e.printStackTrace();
        }
    }
    public void deleteMeeting(int meetingId) {
        try {
            // Prepare SQL statement to delete the meeting from the database
            PreparedStatement statement = connection.prepareStatement("DELETE FROM meetings WHERE meeting_id = ?");
            statement.setInt(1, meetingId);

            // Execute the delete statement
            statement.executeUpdate();
        } catch (SQLException e) {
            // Handle any SQL exceptions
            e.printStackTrace();
        }
    }



    public static void main(String[] args) {
        MeetingDao meetingDao = new MeetingDao();

        // Test fetching meetings for the current user
        List<Meeting> meetings = meetingDao.getMeetingsForCurrentUser("test@example.com");

    }
}
