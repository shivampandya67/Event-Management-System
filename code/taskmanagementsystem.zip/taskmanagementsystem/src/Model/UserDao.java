package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    private Connection connection;

    public UserDao() {
        // Initialize database connection
        try {
            connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/taskmanagement", "root", "root");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to authenticate a user with the provided email and password
    public boolean authenticateUser(String email, String password) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM login WHERE email = ? AND password = ?");
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            // If the query returns any result, the user is authenticated
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Authentication failed due to database error
        }
    }

    // Method to fetch user/client emails from the "user/client" field
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();

        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM login WHERE `user/client` = 'user'");
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                User user = new User(resultSet.getString("email"), resultSet.getString("password"));
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return users;
    }
}

