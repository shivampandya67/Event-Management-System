package Model;

import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserColorMapper {

    private Map<String, Color> userColorMap;

    public UserColorMapper(List<User> users) {
        userColorMap = new HashMap<>();
        assignColors(users);
    }

    private void assignColors(List<User> users) {
        // Predefined set of distinct colors
        Color[] distinctColors = {
            Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.ORANGE,
            Color.CYAN, Color.MAGENTA, Color.PINK, Color.LIGHT_GRAY,
            Color.DARK_GRAY
        };
        
        // Assign distinct colors to users
        int colorIndex = 0;
        for (User user : users) {
            Color color = distinctColors[colorIndex % distinctColors.length];
            userColorMap.put(user.getEmail(), color);
            colorIndex++;
        }
    }

    public Color getColor(String userEmail) {
        return userColorMap.getOrDefault(userEmail, Color.BLACK); // Default color is black
    }
}
