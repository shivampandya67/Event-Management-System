//jframe functional code proper one with ui and database

package View;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import Model.Meeting;
import Model.MeetingDao;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import javax.swing.table.TableCellRenderer;

public class ModifyMeetingDialog extends JFrame {
    private DefaultTableModel hostTableModel;
    private DefaultTableModel participantTableModel;
    private String loggedInUserEmail;
    private MeetingDao meetingDao;
    private List<Integer> hostMeetingIds;
    private boolean isMaximized = false;
    private DashboardView dashboardView; //Track the state of the dialog

    public ModifyMeetingDialog(JFrame parent, List<Meeting> hostMeetings, List<Meeting> participantMeetings, String loggedInUserEmail) {
        super("Modify Meeting");
        setSize(600, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());
        this.loggedInUserEmail = loggedInUserEmail;
        meetingDao = new MeetingDao();
        hostMeetingIds = new ArrayList<>();
        this.dashboardView = dashboardView;

         //Host Meetings Section
        JPanel hostPanel = new JPanel(new BorderLayout());
        hostTableModel = new DefaultTableModel(new Object[]{"Start Date", "Start Time", "End Time", "Edit", "Delete"}, 0);
        JTable hostMeetingTable = new JTable(hostTableModel);
        JScrollPane hostScrollPane = new JScrollPane(hostMeetingTable);        
        hostPanel.add(new JLabel("Host Meetings"), BorderLayout.NORTH);
        hostPanel.add(hostScrollPane, BorderLayout.CENTER);
        add(hostPanel, BorderLayout.CENTER);



        updateHostMeetings(hostMeetings);
        //updateParticipantMeetings(participantMeetings);

        // Set custom cell renderer and editor for the "Edit" and "Delete" columns in host meeting table
        hostMeetingTable.getColumnModel().getColumn(3).setCellRenderer(new ButtonRenderer());
        hostMeetingTable.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox()));
        hostMeetingTable.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
        hostMeetingTable.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(new JCheckBox()));

        

         

         //Set the close operation to hide the frame
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
    }

    public void updateHostMeetings(List<Meeting> meetings) {
        hostTableModel.setRowCount(0);  //Clear existing rows
        hostMeetingIds.clear();  //Clear existing meeting IDs
        for (Meeting meeting : meetings) {
            if (meeting.getUserEmail().equals(loggedInUserEmail)) {  //Only add meetings where the logged-in user is the host
                Object[] rowData = {meeting.getMeetingDate(), meeting.getStartTime(), meeting.getEndTime(), "Edit", "Delete"};
                hostTableModel.addRow(rowData);
                hostMeetingIds.add(meeting.getId()); // Add meeting ID to the list
            }
        }
    }



    private class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setBackground(new Color(0, 102, 204)); // Set button background color
            setForeground(Color.WHITE); // Set button text color
            setBorderPainted(false); // Remove button border
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }

    private class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.setBackground(new Color(0, 102, 204)); // Set button background color
            button.setForeground(Color.WHITE); // Set button text color
            button.setBorderPainted(false); // Remove button border
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                }
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (label.equals("Edit")) {
                        editMeeting(row);
                    } else if (label.equals("Delete")) {
                        deleteMeeting(row);
                    }
                }
            });
            return button;
        }

        public Object getCellEditorValue() {
            return label;
        }



        private void editMeeting(int row) {
            // Get the current meeting details
            Date meetingDate = (Date) hostTableModel.getValueAt(row, 0);
            String startTime = hostTableModel.getValueAt(row, 1).toString();
            String endTime = hostTableModel.getValueAt(row, 2).toString();
            int meetingId = hostMeetingIds.get(row); // Assuming you have a list of meeting IDs

            // Create input fields for editing
            JTextField startDateField = new JTextField(meetingDate.toString());
            JTextField startTimeField = new JTextField(startTime);
            JTextField endTimeField = new JTextField(endTime);

            // Create panel to hold input fields
            JPanel editPanel = new JPanel(new GridLayout(0, 2));
            editPanel.add(new JLabel("Start Date (YYYY-MM-DD):"));
            editPanel.add(startDateField);
            editPanel.add(new JLabel("Start Time (HH:MM):"));
            editPanel.add(startTimeField);
            editPanel.add(new JLabel("End Time (HH:MM):"));
            editPanel.add(endTimeField);

            // Show input dialog
            int result = JOptionPane.showConfirmDialog(null, editPanel, "Edit Meeting", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                // Update meeting details if OK is clicked
                hostTableModel.setValueAt(startDateField.getText(), row, 0);
                hostTableModel.setValueAt(startTimeField.getText(), row, 1);
                hostTableModel.setValueAt(endTimeField.getText(), row, 2);

                // Get the updated values
                Date newMeetingDate = Date.valueOf(startDateField.getText());
                String newStartTime = startTimeField.getText();
                String newEndTime = endTimeField.getText();

                // Update meeting in the database
                meetingDao.updateMeeting(loggedInUserEmail, meetingId, newMeetingDate, newStartTime, newEndTime);
                //dashboardView.refreshDashboard(loggedInUserEmail);
                // Show message to indicate successful update
                JOptionPane.showMessageDialog(null, "Meeting updated successfully.");
                dashboardView.refreshDashboard(loggedInUserEmail);
}
        }
        private void deleteMeeting(int row) {
            // Get the meeting ID from the table model
            int meetingId = hostMeetingIds.get(row); // Assuming you have a list of meeting IDs

            int confirmDelete = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this meeting?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirmDelete == JOptionPane.YES_OPTION) {// Delete meeting from the database
            meetingDao.deleteMeeting(meetingId);

            // Remove meeting from the table model
            hostTableModel.removeRow(row);
            dashboardView.refreshDashboard(loggedInUserEmail);
            // Show message to indicate successful deletion
            JOptionPane.showMessageDialog(null, "Meeting deleted successfully.");
        }
        }
    }
}



        
    



