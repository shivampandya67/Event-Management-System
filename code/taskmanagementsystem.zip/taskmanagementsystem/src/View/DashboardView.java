package View;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import Model.User;
import Model.UserColorMapper;
import Model.UserDao;
import Model.Meeting;
import Model.MeetingDao;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DashboardView extends JFrame {

    
	private JComboBox<String> userDropdown;
    private UserColorMapper colorMapper;
    private JPanel gridPanel;

    public DashboardView(List<User> users, String loggedInUserEmail) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        colorMapper = new UserColorMapper(users);

        JPanel mainPanel = new JPanel(new BorderLayout());
        getContentPane().add(mainPanel);

        gridPanel = new JPanel(new GridLayout(0, 8));
        populateGridPanel(loggedInUserEmail);
        mainPanel.add(gridPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton modify = new JButton("Modify");
        JButton schedule = new JButton("Schedule");
        JButton downloadPDFButton = new JButton("Download as PDF");
        buttonPanel.add(downloadPDFButton);
        userDropdown = new JComboBox<>();
        populateUserDropdown(users);
        buttonPanel.add(modify);
        buttonPanel.add(schedule);
        buttonPanel.add(downloadPDFButton); 
        buttonPanel.add(userDropdown);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        
        
     // Apply custom styling to the dropdown menu
        userDropdown.setOpaque(true);
        userDropdown.setBackground(Color.WHITE);
        userDropdown.setForeground(Color.BLACK);
        userDropdown.setFont(new Font("Tahoma", Font.PLAIN, 14));
        userDropdown.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        userDropdown.setPreferredSize(new Dimension(220, 30)); // Increased width of the dropdown menu

        // Style modifications
        mainPanel.setBackground(new Color(240, 248, 255)); // Light Blue background color
        modify.setForeground(Color.WHITE); // Text color
        modify.setBackground(new Color(70, 130, 180)); // Button background color (Steel Blue)
        modify.setFocusPainted(false); // Remove focus border
        schedule.setForeground(Color.WHITE); // Text color
        schedule.setBackground(new Color(70, 130, 180)); // Button background color (Steel Blue)
        schedule.setFocusPainted(false); // Remove focus border
        downloadPDFButton.setForeground(Color.WHITE); // Text color
        downloadPDFButton.setBackground(new Color(70, 130, 180)); // Button background color (Steel Blue)
        downloadPDFButton.setFocusPainted(false);

        userDropdown.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedUserEmail = (String) userDropdown.getSelectedItem();
                populateGridPanel(selectedUserEmail);
            }
        });

        modify.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                List<Meeting> userMeetings = getMeetingsForUser(loggedInUserEmail);
                ModifyMeetingDialog modifyMeetingDialog = new ModifyMeetingDialog(DashboardView.this, userMeetings, userMeetings, loggedInUserEmail);
                modifyMeetingDialog.setVisible(true);
            }
        });

        schedule.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openScheduleFormView(users, loggedInUserEmail);
            }
        });
        downloadPDFButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generatePDF(getMeetingsForUser(loggedInUserEmail));
            }
        });
    }
    

    private List<Meeting> getMeetingsForUser(String userEmail) {
        MeetingDao meetingDao = new MeetingDao();
        return meetingDao.getMeetingsForCurrentUser(userEmail);
    }
    private void generatePDF(List<Meeting> meetings) {
        Document document = new Document();

        try {
            PdfWriter.getInstance(document, new FileOutputStream("meetings.pdf"));
            document.open();
            
            for (Meeting meeting : meetings) {
                StringBuilder meetingDetails = new StringBuilder();
                meetingDetails.append("Host : ").append(meeting.getUserEmail()).append("\n");
                meetingDetails.append("Meeting Date: ").append(meeting.getMeetingDate()).append("\n");
                meetingDetails.append("Start Time: ").append(meeting.getStartTime()).append("\n");
                meetingDetails.append("End Time: ").append(meeting.getEndTime()).append("\n");
                meetingDetails.append("Participants: ").append(meeting.getParticipants()).append("\n\n");
                
                document.add(new Paragraph(meetingDetails.toString()));
            }
            
            document.close();
            JOptionPane.showMessageDialog(this, "PDF generated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("PDF generated successfully.");
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(this, "Error: File not found - " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (DocumentException e) {
            JOptionPane.showMessageDialog(this, "Error: Document exception - " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void populateGridPanel(String userEmail) {
        String[] daysOfWeek = {"", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

        gridPanel.removeAll();

        Calendar calendar = Calendar.getInstance();
        java.sql.Date currentDate = new java.sql.Date(calendar.getTimeInMillis());

        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        java.sql.Date startDate = new java.sql.Date(calendar.getTimeInMillis());
        calendar.add(Calendar.DATE, 6);
        java.sql.Date endDate = new java.sql.Date(calendar.getTimeInMillis());

        List<Meeting> meetings = getMeetingsForUser(userEmail);

        for (int i = 0; i < daysOfWeek.length; i++) {
            JLabel dayLabel = new JLabel(daysOfWeek[i]);
            dayLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center align day labels
            gridPanel.add(dayLabel);
        }

        for (int hour = 0; hour <= 24; hour++) {
            gridPanel.add(new JLabel(Integer.toString(hour)));
            for (int day = 1; day <= 7; day++) {
                JPanel cellPanel = new JPanel();
                cellPanel.setBorder(new LineBorder(Color.BLACK));
                String cellKey = daysOfWeek[day] + hour;
                Color cellColor = getColorForMeeting(cellKey, meetings);
                cellPanel.setBackground(cellColor);
                String meetingTiming = getMeetingTiming(cellKey, meetings);
                cellPanel.setToolTipText(meetingTiming.isEmpty() ? "No meeting scheduled" : meetingTiming);
                gridPanel.add(cellPanel);
            }
        }

        getContentPane().validate();
        getContentPane().repaint();
    }

    private Color getColorForMeeting(String cellKey, List<Meeting> meetings) {
        for (Meeting meeting : meetings) {
            String meetingDayOfWeek = getDayOfWeek(meeting.getMeetingDate());
            int meetingStartHour = Integer.parseInt(meeting.getStartTime().substring(0, 2));
            int meetingStartMinute = Integer.parseInt(meeting.getStartTime().substring(3, 5));
            int meetingEndHour = Integer.parseInt(meeting.getEndTime().substring(0, 2));
            int meetingEndMinute = Integer.parseInt(meeting.getEndTime().substring(3, 5));

            for (int hour = meetingStartHour; hour <= meetingEndHour; hour++) {
                if (hour == meetingStartHour && hour == meetingEndHour) {
                    if (Integer.parseInt(meeting.getEndTime().substring(3, 5)) <= 30) {
                        if ((meetingDayOfWeek + hour).equals(cellKey))
                            return colorMapper.getColor(meeting.getUserEmail());
                    } else {
                        if ((meetingDayOfWeek + hour).equals(cellKey) || (meetingDayOfWeek + (hour + 1)).equals(cellKey))
                            return colorMapper.getColor(meeting.getUserEmail());
                    }
                } else if (hour == meetingStartHour) {
                    if ((meetingDayOfWeek + hour).equals(cellKey))
                        return colorMapper.getColor(meeting.getUserEmail());
                } else if (hour == meetingEndHour) {
                    if ((meetingDayOfWeek + hour).equals(cellKey))
                        return colorMapper.getColor(meeting.getUserEmail());
                } else {
                    if ((meetingDayOfWeek + hour).equals(cellKey) || (meetingDayOfWeek + (hour + 1)).equals(cellKey))
                        return colorMapper.getColor(meeting.getUserEmail());
                }
            }
        }
        return Color.WHITE;
    }

    private String getMeetingTiming(String cellKey, List<Meeting> meetings) {
        StringBuilder timing = new StringBuilder();
        for (Meeting meeting : meetings) {
            String meetingDayOfWeek = getDayOfWeek(meeting.getMeetingDate());
            int meetingStartHour = Integer.parseInt(meeting.getStartTime().substring(0, 2));
            int meetingEndHour = Integer.parseInt(meeting.getEndTime().substring(0, 2));

            if (cellKey.startsWith(meetingDayOfWeek)) {
                if (Integer.parseInt(cellKey.substring(meetingDayOfWeek.length())) >= meetingStartHour &&
                        Integer.parseInt(cellKey.substring(meetingDayOfWeek.length())) <= meetingEndHour) {
                    timing.append(meeting.getStartTime()).append(" to ").append(meeting.getEndTime()).append("\n");
                }
            }
        }
        return timing.toString();
    }

    private String getDayOfWeek(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        String[] daysOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        return daysOfWeek[dayOfWeek - 1];
    }

    private void openScheduleFormView(List<User> users, String loggedInUserEmail) {
        ScheduleFormView scheduleFormView = new ScheduleFormView(this, users, loggedInUserEmail);
        scheduleFormView.setVisible(true);
    }

    public void populateUserDropdown(List<User> users) {
        for (User user : users) {
            userDropdown.addItem(user.getEmail());
        }
    }

    public void refreshDashboard(String userEmail) {
        populateGridPanel(userEmail);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UserDao userDao = new UserDao();
            List<User> users = userDao.getAllUsers();
            DashboardView dashboardView = new DashboardView(users, "loggedInUserEmail");
            dashboardView.setVisible(true);
        });
    }
}




//package View;
//
//import javax.swing.*;
//import javax.swing.border.EmptyBorder;
//import javax.swing.border.LineBorder;
//
//import Model.User;
//import Model.UserColorMapper;
//import Model.UserDao;
//import Model.Meeting;
//import Model.MeetingDao;
//
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.sql.Date;
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.List;
//
//public class DashboardView extends JFrame {
//
//    private JComboBox<String> userDropdown;
//    private UserColorMapper colorMapper;
//    private JPanel gridPanel;
//
//    public DashboardView(List<User> users, String loggedInUserEmail) {
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setExtendedState(JFrame.MAXIMIZED_BOTH);
//
//        colorMapper = new UserColorMapper(users);
//
//        JPanel mainPanel = new JPanel(new BorderLayout());
//        getContentPane().add(mainPanel);
//
//        gridPanel = new JPanel(new GridLayout(0, 8));
//        populateGridPanel(loggedInUserEmail);
//        mainPanel.add(gridPanel, BorderLayout.CENTER);
//
//        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
//        JButton modify = new JButton("Modify");
//        JButton schedule = new JButton("Schedule");
//        userDropdown = new JComboBox<>();
//        populateUserDropdown(users);
//        buttonPanel.add(modify);
//        buttonPanel.add(schedule);
//        buttonPanel.add(userDropdown);
//        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
//        
//        
//     // Apply custom styling to the dropdown menu
//        userDropdown.setOpaque(true);
//        userDropdown.setBackground(Color.WHITE);
//        userDropdown.setForeground(Color.BLACK);
//        userDropdown.setFont(new Font("Tahoma", Font.PLAIN, 14));
//        userDropdown.setBorder(BorderFactory.createLineBorder(Color.BLACK));
//        userDropdown.setPreferredSize(new Dimension(220, 30)); // Increased width of the dropdown menu
//
//        // Style modifications
//        mainPanel.setBackground(new Color(240, 248, 255)); // Light Blue background color
//        modify.setForeground(Color.WHITE); // Text color
//        modify.setBackground(new Color(70, 130, 180)); // Button background color (Steel Blue)
//        modify.setFocusPainted(false); // Remove focus border
//        schedule.setForeground(Color.WHITE); // Text color
//        schedule.setBackground(new Color(70, 130, 180)); // Button background color (Steel Blue)
//        schedule.setFocusPainted(false); // Remove focus border
//
//        userDropdown.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                String selectedUserEmail = (String) userDropdown.getSelectedItem();
//                populateGridPanel(selectedUserEmail);
//            }
//        });
//
//        modify.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                List<Meeting> userMeetings = getMeetingsForUser(loggedInUserEmail);
//                ModifyMeetingDialog modifyMeetingDialog = new ModifyMeetingDialog(DashboardView.this, userMeetings, userMeetings, loggedInUserEmail);
//                modifyMeetingDialog.setVisible(true);
//            }
//        });
//
//        schedule.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                openScheduleFormView(users, loggedInUserEmail);
//            }
//        });
//    }
//
//    private List<Meeting> getMeetingsForUser(String userEmail) {
//        MeetingDao meetingDao = new MeetingDao();
//        return meetingDao.getMeetingsForCurrentUser(userEmail);
//    }
//
//    private void populateGridPanel(String userEmail) {
//        String[] daysOfWeek = {"", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
//
//        gridPanel.removeAll();
//
//        Calendar calendar = Calendar.getInstance();
//        java.sql.Date currentDate = new java.sql.Date(calendar.getTimeInMillis());
//
//        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
//        java.sql.Date startDate = new java.sql.Date(calendar.getTimeInMillis());
//        calendar.add(Calendar.DATE, 6);
//        java.sql.Date endDate = new java.sql.Date(calendar.getTimeInMillis());
//
//        List<Meeting> meetings = getMeetingsForUser(userEmail);
//
//        for (int i = 0; i < daysOfWeek.length; i++) {
//            JLabel dayLabel = new JLabel(daysOfWeek[i]);
//            dayLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center align day labels
//            gridPanel.add(dayLabel);
//        }
//
//        for (int hour = 0; hour <= 24; hour++) {
//            gridPanel.add(new JLabel(Integer.toString(hour)));
//            for (int day = 1; day <= 7; day++) {
//                JPanel cellPanel = new JPanel();
//                cellPanel.setBorder(new LineBorder(Color.BLACK));
//                String cellKey = daysOfWeek[day] + hour;
//                Color cellColor = getColorForMeeting(cellKey, meetings);
//                cellPanel.setBackground(cellColor);
//                String meetingTiming = getMeetingTiming(cellKey, meetings);
//                cellPanel.setToolTipText(meetingTiming.isEmpty() ? "No meeting scheduled" : meetingTiming);
//                gridPanel.add(cellPanel);
//            }
//        }
//
//        getContentPane().validate();
//        getContentPane().repaint();
//    }
//
//    private Color getColorForMeeting(String cellKey, List<Meeting> meetings) {
//        for (Meeting meeting : meetings) {
//            String meetingDayOfWeek = getDayOfWeek(meeting.getMeetingDate());
//            int meetingStartHour = Integer.parseInt(meeting.getStartTime().substring(0, 2));
//            int meetingStartMinute = Integer.parseInt(meeting.getStartTime().substring(3, 5));
//            int meetingEndHour = Integer.parseInt(meeting.getEndTime().substring(0, 2));
//            int meetingEndMinute = Integer.parseInt(meeting.getEndTime().substring(3, 5));
//
//            for (int hour = meetingStartHour; hour <= meetingEndHour; hour++) {
//                if (hour == meetingStartHour && hour == meetingEndHour) {
//                    if (Integer.parseInt(meeting.getEndTime().substring(3, 5)) <= 30) {
//                        if ((meetingDayOfWeek + hour).equals(cellKey))
//                            return colorMapper.getColor(meeting.getUserEmail());
//                    } else {
//                        if ((meetingDayOfWeek + hour).equals(cellKey) || (meetingDayOfWeek + (hour + 1)).equals(cellKey))
//                            return colorMapper.getColor(meeting.getUserEmail());
//                    }
//                } else if (hour == meetingStartHour) {
//                    if ((meetingDayOfWeek + hour).equals(cellKey))
//                        return colorMapper.getColor(meeting.getUserEmail());
//                } else if (hour == meetingEndHour) {
//                    if ((meetingDayOfWeek + hour).equals(cellKey))
//                        return colorMapper.getColor(meeting.getUserEmail());
//                } else {
//                    if ((meetingDayOfWeek + hour).equals(cellKey) || (meetingDayOfWeek + (hour + 1)).equals(cellKey))
//                        return colorMapper.getColor(meeting.getUserEmail());
//                }
//            }
//        }
//        return Color.WHITE;
//    }
//
//    private String getMeetingTiming(String cellKey, List<Meeting> meetings) {
//        StringBuilder timing = new StringBuilder();
//        for (Meeting meeting : meetings) {
//            String meetingDayOfWeek = getDayOfWeek(meeting.getMeetingDate());
//            int meetingStartHour = Integer.parseInt(meeting.getStartTime().substring(0, 2));
//            int meetingEndHour = Integer.parseInt(meeting.getEndTime().substring(0, 2));
//
//            if (cellKey.startsWith(meetingDayOfWeek)) {
//                if (Integer.parseInt(cellKey.substring(meetingDayOfWeek.length())) >= meetingStartHour &&
//                        Integer.parseInt(cellKey.substring(meetingDayOfWeek.length())) <= meetingEndHour) {
//                    timing.append(meeting.getStartTime()).append(" to ").append(meeting.getEndTime()).append("\n");
//                }
//            }
//        }
//        return timing.toString();
//    }
//
//    private String getDayOfWeek(Date date) {
//        Calendar cal = Calendar.getInstance();
//        cal.setTime(date);
//        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
//        String[] daysOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
//        return daysOfWeek[dayOfWeek - 1];
//    }
//
//    private void openScheduleFormView(List<User> users, String loggedInUserEmail) {
//        ScheduleFormView scheduleFormView = new ScheduleFormView(this, users, loggedInUserEmail);
//        scheduleFormView.setVisible(true);
//    }
//
//    public void populateUserDropdown(List<User> users) {
//        for (User user : users) {
//            userDropdown.addItem(user.getEmail());
//        }
//    }
//
//    public void refreshDashboard(String userEmail) {
//        populateGridPanel(userEmail);
//    }
//
//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(() -> {
//            UserDao userDao = new UserDao();
//            List<User> users = userDao.getAllUsers();
//            DashboardView dashboardView = new DashboardView(users, "loggedInUserEmail");
//            dashboardView.setVisible(true);
//        });
//    }
//}
//
//
//
//
