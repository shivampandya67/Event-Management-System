package View;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class UserOrClient extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JButton btnClient;
    private JButton btnUser;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UserOrClient frame = new UserOrClient();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public UserOrClient() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(240, 248, 255)); // Logic page background color
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Client or User?");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel.setBounds(141, 64, 230, 25);
        contentPane.add(lblNewLabel);
        
        btnClient = new JButton("Client");
        btnClient.setFont(new Font("Tahoma", Font.BOLD, 15));
        btnClient.setBounds(65, 123, 107, 45);
        btnClient.setBackground(new Color(0, 102, 204)); // Button background color
        btnClient.setForeground(Color.WHITE); // Button text color
        btnClient.setBorderPainted(false); // Remove button border
        btnClient.setFocusPainted(false); // Remove button focus border
        contentPane.add(btnClient);
        
        btnUser = new JButton("User");
        btnUser.setFont(new Font("Tahoma", Font.BOLD, 15));
        btnUser.setBounds(245, 123, 107, 45);
        btnUser.setBackground(new Color(0, 102, 204)); // Button background color
        btnUser.setForeground(Color.WHITE); // Button text color
        btnUser.setBorderPainted(false); // Remove button border
        btnUser.setFocusPainted(false); // Remove button focus border
        contentPane.add(btnUser);
    }

    // Method to add action listener to the client button
    public void addClientButtonListener(ActionListener listener) {
        btnClient.addActionListener(listener);
    }

    // Method to add action listener to the user button
    public void addUserButtonListener(ActionListener listener) {
        btnUser.addActionListener(listener);
    }
}

