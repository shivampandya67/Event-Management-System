package View;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import com.toedter.calendar.JDateChooser;
import java.util.List;
import Model.User;
import Model.Meeting;
import Model.MeetingDao;

public class ScheduleFormView extends JDialog {

    private JPanel contentPane;
    private JTextField startTimeField;
    private JTextField endTimeField;
    private JDateChooser dateChooser;
    private JList<String> userList;
    private String loggedInUserEmail; // Added loggedInUserEmail as an instance variable
    private DashboardView dashboardView; // Added DashboardView reference

    public ScheduleFormView(DashboardView owner, List<User> users, String loggedInUserEmail) {
        super(owner, "Schedule a Meeting", true);
        this.dashboardView = owner; // Initialize the DashboardView reference
        this.loggedInUserEmail = loggedInUserEmail; // Initialize loggedInUserEmail
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 600, 400); // Increased width and height of the window
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("Select Users");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel.setBounds(56, 50, 130, 25);
        contentPane.add(lblNewLabel);

        DefaultListModel<String> model = new DefaultListModel<>();
        for (User user : users) {
            if (!user.getEmail().equals(loggedInUserEmail)) {
                model.addElement(user.getEmail());
            }
        }

        userList = new JList<>(model);
        userList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollPane = new JScrollPane(userList);
        scrollPane.setBounds(216, 50, 155, 100);
        contentPane.add(scrollPane);

        JLabel lblNewLabel_1 = new JLabel("Pick Date");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel_1.setBounds(56, 160, 130, 25);
        contentPane.add(lblNewLabel_1);

        dateChooser = new JDateChooser();
        dateChooser.setBounds(216, 160, 155, 25);
        contentPane.add(dateChooser);

        JLabel lblTimeHr = new JLabel("Start Time");
        lblTimeHr.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblTimeHr.setBounds(56, 200, 180, 25); // Increased width to accommodate longer label
        contentPane.add(lblTimeHr);

        startTimeField = new JTextField();
        startTimeField.setBounds(216, 200, 155, 25); // Adjusted height to match font size
        contentPane.add(startTimeField);
        startTimeField.setColumns(10);

        JLabel lblEndTime = new JLabel("End Time");
        lblEndTime.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblEndTime.setBounds(56, 240, 180, 25); // Increased width to accommodate longer label
        contentPane.add(lblEndTime);

        endTimeField = new JTextField();
        endTimeField.setBounds(216, 240, 155, 25); // Adjusted height to match font size
        contentPane.add(endTimeField);
        endTimeField.setColumns(10);

        JButton button1 = new JButton("Submit");
        button1.setBounds(216, 300, 120, 30); // Adjusted position and size of the button
        contentPane.add(button1);

        JLabel lblNewLabel_2 = new JLabel("Schedule a Meeting");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel_2.setBounds(212, 10, 206, 25); // Adjusted position of the label
        contentPane.add(lblNewLabel_2);

        // UI Improvements
        contentPane.setBackground(new Color(240, 248, 255)); // Set background color
        lblNewLabel.setForeground(Color.BLACK); // Set label text color
        lblNewLabel_1.setForeground(Color.BLACK); // Set label text color
        lblTimeHr.setForeground(Color.BLACK); // Set label text color
        lblEndTime.setForeground(Color.BLACK); // Set label text color
        lblNewLabel_2.setForeground(Color.BLACK); // Set label text color

        button1.setBackground(new Color(0, 102, 204)); // Set background color of the button
        button1.setForeground(Color.WHITE); // Set text color of the button
        button1.setBorderPainted(false); // Remove button border
        button1.setFocusPainted(false); // Remove button focus border

        button1.addActionListener(e -> {
            // Check if any field is empty
            if (userList.isSelectionEmpty() || dateChooser.getDate() == null || startTimeField.getText().isEmpty() || endTimeField.getText().isEmpty()) {
                // Display error message if any field is empty
                JOptionPane.showMessageDialog(this, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Get selected users' emails
                List<String> selectedUsers = userList.getSelectedValuesList();

                // Get selected date
                java.util.Date selectedDate = dateChooser.getDate();
                
                if (selectedDate.before(new java.util.Date())) {
                    // Display error message if the selected date is in the past
                    JOptionPane.showMessageDialog(this, "Selected date cannot be in the past", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                java.sql.Date sqlDate = new java.sql.Date(selectedDate.getTime());

                // Get start and end times
                String startTime = startTimeField.getText();
                String endTime = endTimeField.getText();

                // Validate start time format
                if (!isValidTimeFormat(startTime) || !isValidTimeFormat(endTime)) {
                    // Display error message if time format is invalid
                    JOptionPane.showMessageDialog(this, "Time format should be HH:MM", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Check if end time is smaller than start time
                if (isEndTimeSmaller(startTime, endTime)) {
                    JOptionPane.showMessageDialog(this, "End time cannot be smaller than start time", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Check for meeting conflict
                MeetingDao meetingDao = new MeetingDao();
                boolean conflict = meetingDao.isMeetingConflict(new Meeting(getDefaultCloseOperation(), sqlDate, startTime, endTime, loggedInUserEmail, selectedUsers), userList.getSelectedValuesList());

                //boolean conflict = meetingDao.isMeetingConflict(new Meeting(getDefaultCloseOperation(), sqlDate, startTime, endTime, loggedInUserEmail, selectedUsers), selectedUsers);
                // If there is a conflict, display an error message and return
                if (conflict) {
                    JOptionPane.showMessageDialog(this, "There is a meeting conflict. Meeting cannot be scheduled.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Insert meeting into database using the new method
                meetingDao.insertMeetingFromForm(new Meeting(getDefaultCloseOperation(), sqlDate, startTime, endTime, loggedInUserEmail, selectedUsers), selectedUsers);

                // Display success message
                JOptionPane.showMessageDialog(this, "Meeting scheduled successfully!");

                // Refresh the dashboard to reflect the new meeting
                dashboardView.refreshDashboard(loggedInUserEmail);
                
                // Reset form fields
                userList.clearSelection(); // Clear selection in the user list
                startTimeField.setText(""); // Clear start time text field
                endTimeField.setText(""); // Clear end time text field
                dateChooser.setDate(null); // Reset date chooser to null
            }
        });
        }


        private boolean isEndTimeSmaller(String startTime, String endTime) {
            // Parse hours and minutes from start and end time strings
            String[] startTimeParts = startTime.split(":");
            String[] endTimeParts = endTime.split(":");

            int startHour = Integer.parseInt(startTimeParts[0]);
            int startMinute = Integer.parseInt(startTimeParts[1]);
            int endHour = Integer.parseInt(endTimeParts[0]);
            int endMinute = Integer.parseInt(endTimeParts[1]);

            // Check if end time is smaller than start time
            return endHour < startHour || (endHour == startHour && endMinute < startMinute);
        }

    
    private boolean isValidTimeFormat(String time) {
        // Regular expression to validate time format (HH:MM)
        String timeRegex = "([01]?[0-9]|2[0-3]):[0-5][0-9]";
        return time.matches(timeRegex);
    }
}


