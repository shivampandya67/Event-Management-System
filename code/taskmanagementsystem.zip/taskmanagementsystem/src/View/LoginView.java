package View;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class LoginView extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField email;
    private JPasswordField password;
    private JButton signInButton;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    LoginView frame = new LoginView();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public LoginView() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(240, 248, 255)); // Light Blue background color
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Email:");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel.setBounds(50, 74, 92, 38);
        contentPane.add(lblNewLabel);
        
        email = new JTextField();
        email.setBounds(135, 79, 255, 28);
        contentPane.add(email);
        email.setColumns(10);
        
        JLabel lblNewLabel_1 = new JLabel("Password:");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel_1.setBounds(10, 122, 109, 38);
        contentPane.add(lblNewLabel_1);
        
        password = new JPasswordField();
        password.setBounds(135, 122, 255, 33);
        contentPane.add(password);
        
        JLabel lblNewLabel_2 = new JLabel("Login");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 24)); // Increased font size
        lblNewLabel_2.setBounds(180, 26, 146, 28);
        contentPane.add(lblNewLabel_2);
        
        signInButton = new JButton("Sign in");
        signInButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        signInButton.setForeground(Color.WHITE); // Text color
        signInButton.setBackground(new Color(70, 130, 180)); // Button background color (Steel Blue)
        signInButton.setFocusPainted(false); // Remove focus border
        signInButton.setBounds(139, 194, 126, 40); // Increased button height
        contentPane.add(signInButton);
    }

    // Method to get the entered email
    public String getEmail() {
        return email.getText();
    }

    // Method to get the entered password
    public String getPassword() {
        return new String(password.getPassword());
    }

    // Method to add ActionListener to the submit button
    public void addSubmitActionListener(ActionListener listener) {
        signInButton.addActionListener(listener);
    }

    // Method to show success message
    public void showSuccessMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    // Method to show error message
    public void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
}

