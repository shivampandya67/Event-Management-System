package View;

import javax.swing.*;
import javax.swing.border.LineBorder;

import Model.User;
import Model.UserColorMapper;
import Model.Meeting;
import Model.MeetingDao;
import Model.UserDao;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ClientDashboardView extends JFrame {

    private JComboBox<String> userDropdown;
    private UserColorMapper colorMapper;
    private JPanel gridPanel; // Added gridPanel as an instance variable

    public ClientDashboardView(List<User> users) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        colorMapper = new UserColorMapper(users);

        JPanel mainPanel = new JPanel(new BorderLayout());
        getContentPane().add(mainPanel);

        // Set background color to match the login page
        mainPanel.setBackground(new Color(240, 248, 255));

        gridPanel = new JPanel(new GridLayout(0, 8)); // Moved gridPanel initialization here
        mainPanel.add(gridPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        userDropdown = new JComboBox<>();
        populateUserDropdown(users);

        // Apply custom styling to the dropdown menu
        userDropdown.setOpaque(true);
        userDropdown.setBackground(Color.WHITE);
        userDropdown.setForeground(Color.BLACK);
        userDropdown.setFont(new Font("Tahoma", Font.PLAIN, 14));
        userDropdown.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        userDropdown.setPreferredSize(new Dimension(220,30));

        userDropdown.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedUserEmail = (String) userDropdown.getSelectedItem();
                populateGridPanel(selectedUserEmail);
            }
        });

        buttonPanel.add(userDropdown);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Populate the grid panel initially with the first user in the dropdown
        if (!users.isEmpty()) {
            String selectedUserEmail = users.get(0).getEmail();
            populateGridPanel(selectedUserEmail);
        }
    }

    // Method to retrieve meetings for the specified user
    private List<Meeting> getMeetingsForUser(String userEmail) {
        MeetingDao meetingDao = new MeetingDao();
        return meetingDao.getMeetingsForCurrentUser(userEmail);
    }

    // Method to populate the grid panel with meetings for the specified user
    private void populateGridPanel(String userEmail) {
        gridPanel.removeAll(); // Clear the existing content of the grid panel

        String[] daysOfWeek = {"", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        for (String day : daysOfWeek) {
            JLabel dayLabel = new JLabel(day);
            dayLabel.setHorizontalAlignment(SwingConstants.CENTER); // Center align day labels
            gridPanel.add(dayLabel);
        }

        // Get the current date
        Calendar calendar = Calendar.getInstance();
        java.sql.Date currentDate = new java.sql.Date(calendar.getTimeInMillis());

        // Determine the start and end dates of the current week
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        java.sql.Date startDate = new java.sql.Date(calendar.getTimeInMillis());
        calendar.add(Calendar.DATE, 6);
        java.sql.Date endDate = new java.sql.Date(calendar.getTimeInMillis());

        List<Meeting> meetings = getMeetingsForUser(userEmail); // Retrieve meetings for the specified user

        // Filter meetings to include only those within the current week
        List<Meeting> meetingsInCurrentWeek = new ArrayList<>();
        for (Meeting meeting : meetings) {
            if (!meeting.getMeetingDate().before(startDate) && !meeting.getMeetingDate().after(endDate)) {
                meetingsInCurrentWeek.add(meeting);
            }
        }

        for (int hour = 0; hour <= 24; hour++) {
            gridPanel.add(new JLabel(Integer.toString(hour)));
            for (int day = 1; day <= 7; day++) {
                JPanel cellPanel = new JPanel();
                cellPanel.setBorder(new LineBorder(Color.BLACK));
                String cellKey = daysOfWeek[day] + hour;
                Color cellColor = getColorForMeeting(cellKey, meetingsInCurrentWeek); // Determine color for the meeting slot
                cellPanel.setBackground(cellColor);

                // Add tooltip with meeting time information when hovering over the cell
                cellPanel.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        Meeting meeting = getMeetingForCell(cellKey, meetingsInCurrentWeek);
                        if (meeting != null) {
                            String tooltipText = "Meeting Time: " + meeting.getStartTime() + " - " + meeting.getEndTime();
                            cellPanel.setToolTipText(tooltipText);
                        }
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        cellPanel.setToolTipText(null); // Clear tooltip when mouse exits
                    }
                });

                gridPanel.add(cellPanel);
            }
        }

        // Refresh the main panel to reflect the changes
        getContentPane().validate();
        getContentPane().repaint();
    }

    // Retrieve the meeting for the specified cell, if any
    private Meeting getMeetingForCell(String cellKey, List<Meeting> meetings) {
        for (Meeting meeting : meetings) {
            String meetingDayOfWeek = getDayOfWeek(meeting.getMeetingDate());
            int meetingStartHour = Integer.parseInt(meeting.getStartTime().substring(0, 2));
            String meetingCellKey = meetingDayOfWeek + meetingStartHour;
            if (meetingCellKey.equals(cellKey)) {
                return meeting;
            }
        }
        return null;
    }

    private Color getColorForMeeting(String cellKey, List<Meeting> meetings) {
        for (Meeting meeting : meetings) {
            String meetingDayOfWeek = getDayOfWeek(meeting.getMeetingDate());
            int meetingStartHour = Integer.parseInt(meeting.getStartTime().substring(0, 2));
            int meetingStartMinute = Integer.parseInt(meeting.getStartTime().substring(3, 5));
            int meetingEndHour = Integer.parseInt(meeting.getEndTime().substring(0, 2));
            int meetingEndMinute = Integer.parseInt(meeting.getEndTime().substring(3, 5));

            // Convert meeting times to minutes
            int meetingStartTotalMinutes = meetingStartHour * 60 + meetingStartMinute;
            int meetingEndTotalMinutes = meetingEndHour * 60 + meetingEndMinute;

            // Check if the cellKey falls within the range of the meeting hours
            for (int hour = meetingStartHour; hour <= meetingEndHour; hour++) {
                String currentCellKey = meetingDayOfWeek + hour;
                if (currentCellKey.equals(cellKey)) {
                    // Check if this is a partial slot
                    boolean isPartialStart = hour == meetingStartHour && meetingStartMinute > 0;
                    boolean isPartialEnd = hour == meetingEndHour && meetingEndMinute < 60;

                    // Determine color for the meeting slot
                    Color color = colorMapper.getColor(meeting.getUserEmail());
                    if (isPartialStart) {
                        // Calculate portion to color based on meeting start minute
                        double portion = (60 - meetingStartMinute) / 60.0;
                        return blendColor(color, Color.WHITE, portion);
                    } else if (isPartialEnd) {
                        // Calculate portion to color based on meeting end minute
                        double portion = meetingEndMinute / 60.0;
                        return blendColor(color, Color.WHITE, portion);
                    } else {
                        // Full hour slot, return full color
                        return color;
                    }
                }
            }
        }
        return Color.WHITE; // Default color
    }

    private Color blendColor(Color color1, Color color2, double portion) {
        // Extract RGB components of both colors
        float[] color1Components = color1.getRGBColorComponents(null);
        float[] color2Components = color2.getRGBColorComponents(null);

        // Interpolate the RGB components based on the given portion
        float[] blendedComponents = new float[3];
        for (int i = 0; i < 3; i++) {
            blendedComponents[i] = (float) (portion * color1Components[i] + (1 - portion) * color2Components[i]);
        }

        // Return the blended color
        return new Color(blendedComponents[0], blendedComponents[1], blendedComponents[2]);
    }

    // Helper method to get the day of the week from a Date object
    private String getDayOfWeek(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        String[] daysOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        return daysOfWeek[dayOfWeek - 1];
    }

    public void populateUserDropdown(List<User> users) {
        for (User user : users) {
            userDropdown.addItem(user.getEmail());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UserDao userDao = new UserDao();
            List<User> users = userDao.getAllUsers();
            ClientDashboardView clientDashboardView = new ClientDashboardView(users);
            clientDashboardView.setVisible(true);
        });
    }
}
